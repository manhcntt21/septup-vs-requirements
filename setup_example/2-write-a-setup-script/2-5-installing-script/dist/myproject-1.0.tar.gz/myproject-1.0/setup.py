from distutils.core import setup

# setup.py

setup(
    name='myproject',
    version='1.0',
    scripts=['myscript.py']  # Chỉ cần cài đặt script
)