def make_sound():
    return "Meow"
