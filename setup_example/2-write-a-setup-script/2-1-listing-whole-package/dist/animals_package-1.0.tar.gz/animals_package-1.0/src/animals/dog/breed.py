def get_breed():
    return ['Husky', 'Poodle', 'Golden Retriever']
