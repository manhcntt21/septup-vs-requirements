def introduction():
    return 'My Calculator'
