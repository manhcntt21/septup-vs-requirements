def foo():
    return 'Hi, I am foo!'
